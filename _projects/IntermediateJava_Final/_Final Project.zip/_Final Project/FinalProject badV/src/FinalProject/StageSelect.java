/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package FinalProject;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.*;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.text.Text;
import javafx.stage.Stage;

/**
 *
 * @author Alan
 */
public class StageSelect extends Application {
    
    
    @Override
    public void start(Stage primaryStage) {
        CDLL cdll = new CDLL();
        BorderPane stageSel = new BorderPane();
        HBox continueBox = new HBox();
        StackPane stageCenter = new StackPane();
        StackPane stageTop = new StackPane();
        StackPane stageRight = new StackPane();
        StackPane stageLeft = new StackPane();
        ImageView stageDisplay = new ImageView();
        stageSel.setPadding(new Insets(10, 10, 10, 10));
        //TextView stageDisplay = new StageView();
        
        //Call Method to Read in from the Database and Store them as Nodes in a List
        //setUpStages();
        

        
        //using numbers will change the image
        cdll.insertAtEnd(1);
        cdll.insertAtEnd(2);
        cdll.insertAtEnd(3);
        for(int i = 0; i < cdll.size; i++)
        {
            //System.out.println(cdll.getInfo());
            System.out.println(stageDisplay);
            cdll.nextNode();
        }
        
        
        Text title = new Text("Stage Select");
        Image grid = new Image("file:image/1.png");
        stageDisplay.setImage(grid);
        //Text stageDisplay = new Text();
        //GridPane stageDisplay = new GridPane();
        Button leftBtn = new Button();
        Button rightBtn = new Button();
        Button continueBt = new Button();
        leftBtn.setText("<<");
        rightBtn.setText(">>");
        continueBt.setText("Continue");
        continueBt.setDisable(true);

        
        
        //Organization, stackpane within a borderpane, and Hbox for continueBt
        stageLeft.getChildren().add(leftBtn);
        stageSel.setLeft(stageLeft);
        
        stageRight.getChildren().add(rightBtn);
        stageSel.setRight(stageRight);
        
        stageCenter.getChildren().add(stageDisplay);
        stageSel.setCenter(stageCenter);
        
        stageTop.getChildren().add(title);
        stageSel.setTop(stageTop);
        
        
        continueBox.getChildren().add(continueBt);
        continueBox.setAlignment(Pos.BOTTOM_RIGHT);
        stageSel.setBottom(continueBox);
        
        leftBtn.setOnAction(new EventHandler<ActionEvent>() {
            
            @Override
            public void handle(ActionEvent event) {
                cdll.prevNode();
                //stageDisplay.setText(Integer.toString(cdll.getInfo()));
                stageDisplay.setImage(
                    new Image("file:image/" + cdll.getInfo() + ".png"));
            }
        });
        rightBtn.setOnAction(new EventHandler<ActionEvent>() {
            
            @Override
            public void handle(ActionEvent event) {
                cdll.nextNode();
                //stageDisplay.setText(Integer.toString(cdll.getInfo()));
                stageDisplay.setImage(
                        new Image("file:image/"+ cdll.getInfo() + ".png"));
                
            }
        });
        
        //allows the continueButton to be clicked
        stageCenter.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
               continueBt.setDisable(false);
               //Swap screens here***********************
            }
        });
        
        
        
        //stageSel.getChildren().addAll(leftBtn, rightBtn, title, stageDisplay);
        Scene scene = new Scene(stageSel, 600, 600);
        primaryStage.setTitle("Stage Selection");
        primaryStage.setScene(scene);
        primaryStage.show();
    }
    
    
    public void stageList()
    {
        
    }

    
    class Node
{
    protected int data;
    protected Node next, prev;
    
    public Node()
    {
        next = null;
        prev = null;
        data = 0;
    }
    
    public Node(int d, Node n, Node p)
    {
        data = d;
        next = n;
        prev = p;
    }
    
    public void setNext(Node n)
    {
        next = n;
    }
    
    public void setPrev(Node p)
    {
        prev = p;
    }
    
    public void setData(int d)
    {
        data = d;
    }
    public Node getPrev()
    {
        return prev;
    }
    public Node getNext()
    {
        return next;
    }
    public int getData()
    {
        return data;
    }
    
}

    //Circular Doubly Linked List
class CDLL
{
    protected Node start;
    protected Node end;
    protected Node currPos;
    public int size;
    
    public CDLL()
    {
        start = null;
        end = null;
        currPos = null;
        size = 0;
    }
    
    public boolean isEmpty()
    {
        return start == null;
    }
    
    public int getSize()
    {
        return size;
    }
    
    public void insertAtStart(int val)
    {
        Node nptr = new Node(val, null, null);
        if(start == null)
        {
            nptr.setNext(nptr);
            nptr.setPrev(nptr);
            start = nptr;
            currPos = start;
            end = start;
        }
        else
        {
            nptr.setPrev(end);
            end.setNext(nptr);
            start.setPrev(nptr);
            nptr.setNext(start);
            start = nptr;
        }
        size++;
    }
    
    //public void insertAtEnd(int val, String location)
    public void insertAtEnd(int val)
    {
        Node nptr = new Node(val, null, null);
        if(start == null)
        {
            nptr.setNext(nptr);
            nptr.setPrev(nptr);
            start = nptr;
            currPos = start;
            end = start;
        }
        else
        {
            nptr.setPrev(end);
            end.setNext(nptr);
            start.setPrev(nptr);
            nptr.setNext(start);
            end = nptr;
        }
        size++;
    }
    public int getInfoAtPos(int pos)
    {
        Node nptr = start;
        Node temp = new Node();
        for(int i = 0; i < size; i++)
        {
            if(pos == i)
            {
                temp.setData(nptr.getData());
            }
            nptr = nptr.getNext();
        }
        return temp.getData();
    }
    
    public int getInfo()
    {
        return currPos.getData();
    }
    
    public void nextNode()
    {
        if(currPos.getNext() != null)
        {
            currPos = currPos.getNext();
        }
    }
    
    public void prevNode()
    {
        if(currPos.getPrev() != null)
        {
            currPos = currPos.getPrev();
        }
    }
    
}
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }
    
}