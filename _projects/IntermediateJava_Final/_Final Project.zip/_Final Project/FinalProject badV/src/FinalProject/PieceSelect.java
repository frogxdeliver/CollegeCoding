/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package FinalProject;

import javafx.application.Application;
import static javafx.application.Application.launch;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextArea;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.stage.Stage;

/**
 *
 * @author Alan
 */
public class PieceSelect extends Application {
    
    @Override
    public void start(Stage primaryStage) {
        BorderPane pieceSel = new BorderPane();
        VBox leftVbox = new VBox();
        VBox centerVbox = new VBox();
        
        ComboBox<String> smallCB = new ComboBox<>();
        ComboBox<String> mediumCB = new ComboBox<>();
        ComboBox<String> largeCB = new ComboBox<>();
        
        ScrollPane rightPane = new ScrollPane();
        TextArea rightText = new TextArea();
        HBox continueBox2 = new HBox();
        StackPane stackTop = new StackPane();
        pieceSel.setPadding(new Insets(10, 10, 10, 10));
        //TextView stageDisplay = new StageView();
        
        //Call Method to Read in from the Database and Store them as Nodes in a List
        //setUpStages();
        
        
        Text title2 = new Text("Piece Select");
        Text sPieceText = new Text();
        Text mPieceText = new Text();
        Text lPieceText = new Text();
        Button continueBt2 = new Button();
        sPieceText.setText("Small");
        mPieceText.setText("Medium");
        lPieceText.setText("Large");
        continueBt2.setText("Continue");
        continueBt2.setDisable(false);

        
        
        //Organization, vbox within a borderpane, and Hbox for continueBt
        leftVbox.getChildren().addAll(sPieceText, mPieceText, lPieceText);
        leftVbox.setSpacing(100);
        leftVbox.setAlignment(Pos.CENTER_LEFT);
        pieceSel.setLeft(leftVbox);
        
        
        smallCB.setValue("White");
        smallCB.getItems().addAll("White", "Blue");
        //smallCB.getItems().addAll("White", "Blue", "Green", "Red", "White");
        mediumCB.setValue("White");
        mediumCB.getItems().addAll("White", "Blue");
        //mediumCB.getItems().addAll("Black", "Blue", "Green", "Red", "White");
        largeCB.setValue("White");
        largeCB.getItems().addAll("White", "Blue");
        //largeCB.getItems().addAll("Black", "Blue", "Greeen", "Red", "White");
        
        //VBox for the comboboxes in the center
        centerVbox.getChildren().addAll(smallCB, mediumCB, largeCB);
        centerVbox.setSpacing(100);
        centerVbox.setAlignment(Pos.CENTER);
        pieceSel.setCenter(centerVbox);
        
        //ScrollPane with text on the right side
        rightText.setFont(Font.font("SansSerif", 12));
        rightText.setPrefSize(435, 800);
        rightText.setWrapText(true);
        rightText.setEditable(false);
        rightText.setText(
                "Each player needs 1 small, 1 medium, and 1 large piece in "
                        + "order to play the game.\n\n" +
                "Piece Sizes determine HP:\n"+
                "Small - 1 HP\n" +
                "Med   - 2 HP\n" + 
                "Large - 3 HP\n\n" +
                
                "Color determine attack and movement direction:\n" +
                "White moves   - vertical and horizontal (no restriction in distance)\n" +
                "White attacks - any adjacent square (like a king in chess)\n"+
                "Blue moves    - vertical and horizontal within 2 tiles\n"+
                "Blue attacks  - any adjacent square within 2 tiles\n");
        rightPane.setContent(rightText);
        rightPane.setPrefSize(450, 800);
        rightPane.setVbarPolicy(ScrollPane.ScrollBarPolicy.AS_NEEDED);
        pieceSel.setRight(rightPane);
        //stackRight.getChildren().add(rightBtn);
        //pieceSel.setRight(stackRight);
        
             
        //stackPane at the top for the title
        stackTop.getChildren().add(title2);
        pieceSel.setTop(stackTop);
        
        
        continueBox2.getChildren().add(continueBt2);
        continueBox2.setAlignment(Pos.BOTTOM_RIGHT);
        pieceSel.setBottom(continueBox2);
        

        //allows the continueButton to be clicked
        /*stackCenter.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
               continueBt.setDisable(false);
               //Swap screens here***********************
            }
        });*/
        
        
        Scene scene = new Scene(pieceSel, 600, 600);
        primaryStage.setTitle("Stage Selection");
        primaryStage.setScene(scene);
        primaryStage.show();
    }
    
    

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }
    
}