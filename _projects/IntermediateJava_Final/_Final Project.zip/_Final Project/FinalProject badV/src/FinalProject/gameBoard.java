/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package FinalProject;

import javafx.application.Application;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextArea;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.stage.Stage;

/**
 *
 * @author Alan
 */
public class gameBoard extends Application {
    
    private static final int NUM_PER_ROW = 6;
    
    @Override
    public void start(Stage primaryStage) {
        GridPane root = new GridPane();
        BorderPane bPane = new BorderPane();
        HBox bottomBox = new HBox();
        VBox rightBox = new VBox();
        
        ScrollPane tRightPane = new ScrollPane();
        ScrollPane bRightPane = new ScrollPane();
        
        TextArea tRightText = new TextArea();
        TextArea bRightText = new TextArea();
        
        Button attackBt = new Button();
        Button moveBt = new Button();
        
        //set the root gridpane in the top left
        bPane.setTop(root);
        //GridPane g1 = new GridPane();
        for(int i = 0; i < 36; i++)
        {
                Tile tile = new Tile(0);
                tile.setTranslateX(50 * (i % NUM_PER_ROW));
                tile.setTranslateY(50 * (i / NUM_PER_ROW));
                root.getChildren().add(tile);
            
        }
        
        //HBox for the bottom attack and move options, disabled initially until ******
        //both players connect, since no connection though, leave them enabled to test button presses
        attackBt.setText("attack");
        //attackBt.setDisable(true);
        moveBt.setText("move");
        //moveBt.setDisable(true);
        bottomBox.setAlignment(Pos.BASELINE_CENTER);
        bottomBox.setSpacing(50);
        bottomBox.getChildren().addAll(attackBt, moveBt);
        bPane.setBottom(bottomBox);
        
        //VBox for the right side
        tRightText.setText("Each player needs 1 small, 1 medium, and 1 large piece in "
                        + "order to play the game.\n\n" +
                "Piece Sizes determine HP:\n"+
                "Small - 1 HP\n" +
                "Med   - 2 HP\n" + 
                "Large - 3 HP\n\n" +
                
                "Color determine attack and movement direction:\n" +
                "White moves   - vertical and horizontal (no restriction in distance)\n" +
                "White attacks - any adjacent square (like a king in chess)\n"+
                "Blue moves    - vertical and horizontal within 2 tiles\n"+
                "Blue attacks  - any adjacent square within 2 tiles\n");
        tRightText.setWrapText(true);
        tRightText.setEditable(false);
        tRightText.setPrefSize(340, 800);
        tRightText.setFont(Font.font("SansSerif", 12));
        tRightPane.setContent(tRightText);
        tRightPane.setPrefSize(345, 800);
        tRightPane.setHbarPolicy(ScrollPane.ScrollBarPolicy.NEVER);
        
        bRightText.setWrapText(true);
        bRightText.setEditable(false);
        bRightText.setPrefSize(340, 800);
        bRightText.setFont(Font.font("SansSerif", 12));
        bRightText.setText("move history"); //<<<<Not sure what method we want to put here...*******
        //But I imagine something like getMoveHistory() that would return a toString()
        //of player1 pieceSize, col row movement or attack
        bRightPane.setContent(bRightText);
        bRightPane.setPrefSize(345, 800);
        bRightPane.setHbarPolicy(ScrollPane.ScrollBarPolicy.NEVER);
        
        rightBox.getChildren().addAll(tRightPane, bRightPane);
        rightBox.setSpacing(10);
        rightBox.setPadding(new Insets(10));
        bPane.setRight(rightBox);

        
        //Button presses
        attackBt.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
               //tile.setAttack(true); ** I know this doesn't work, but I'm having trouble 
               //with how I would do this exactly... Like, I think that moving the buttons into the
               //Tile class would allow this to be possible... But I'm not sure... :/
            }
        });
        moveBt.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
               
            }
        });
        
        
        
        
        
        Scene scene = new Scene(bPane, 700, 700);
        primaryStage.setTitle("Create Board and Highlight Tile Demo");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }

public class Tile extends StackPane{
        
        private int state;
        public boolean playerAttack;
        public boolean playerMove;
        
        /**
         * The Constructor method which takes in the 1-52 value of a card 
         * and assigns it the back image and its corresponding face card
         * @param value - the 1-52 value that cards hold
         */
        Rectangle border;
        public Tile(int value)
        {
            
            //Rectangle border in Tile and the tile.setTranslate to affect gameboard
            border = new Rectangle(50, 50);
            border.setFill(null);
            state = 0;
            border.setStroke(Color.BLACK);
            setAlignment(Pos.CENTER);
            getChildren().addAll(border);
            
            setOnMouseClicked(this::handleMouseClick);
        }
        
         /**
         * This method controls what happens when the user clicks on a tile
         * @param event - the interaction of when the mouse button is clicked
         */
        public void handleMouseClick(MouseEvent event)
        {
            
            //if tile is already open, do nothing
            
//            border.setStroke(Color.TRANSPARENT);
//            border.setFill(Color.WHITE);
//            setState(0);
            /*if(playerMove){
                System.out.println("Current State = " + state);
                System.out.println("Changing to Blue");
                border.setStroke(Color.BLUE);
                border.setFill(Color.BLUE);
                setState(1);
            }else if (playerAttack){
                    System.out.println("Current State = " + state);
                    System.out.println("Changing to Red");
                    border.setStroke(Color.RED);
                    border.setFill(Color.RED);
                    setState(2);
            }*/

                


//                    System.out.println("Current State = " + state);
//                    System.out.println("Changing to White");
//                    border.setStroke(Color.BLACK);
//                    border.setFill(Color.WHITE);
//                    setState(0);
                    
                    
                    
                    

            switch (state) {
                case 0:
                    System.out.println("Current State = " + state);
                    System.out.println("Changing to Blue");
                     border.setStroke(Color.BLUE);
                    border.setFill(Color.BLUE);
                    setState(1);
                    break;
                case 1:
                    System.out.println("Current State = " + state);
                    System.out.println("Changing to Red");
                    border.setStroke(Color.RED);
                    border.setFill(Color.RED);
                    setState(2);
                    break;
                case 2:
                    System.out.println("Current State = " + state);
                    System.out.println("Changing to White");
                    border.setStroke(Color.BLACK);
                    border.setFill(Color.WHITE);
                    setState(0);
                    break;
                default:
                    border.setStroke(Color.BLACK);
                    border.setFill(Color.TRANSPARENT);
                    setState(0);
                    
                    break;
            }
        }
       
        public int getState()
        {
            return this.state;
        }
        public void setState(int v)
        {
            this.state = v;
        }
        public boolean getAttack()
        {
            return this.playerAttack;
        }
        public void setAttack(boolean a)
        {
            this.playerAttack = a;
        }
        //public boolean getMove(){
        
    }
}
