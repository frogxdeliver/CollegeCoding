/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package FinalProject;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.StackPane;
import javafx.scene.text.Text;
import javafx.stage.Stage;

/**
 *
 * @author Alan
 */
public class SwitchScreens extends Application {
    
    Scene scene;
    Scene s1;
    Scene s2;
    StackPane root;
    BorderPane bp;
    Button b2;
    @Override
    public void start(Stage primaryStage) {
        setUp2ndScene();
        Button btn = new Button();
        btn.setText("Go to 2nd screen");
        root = new StackPane();
        root.getChildren().add(btn);
        
        s1 = new Scene(root, 200, 200);
        s2 = new Scene(bp, 300, 250);
        btn.setOnAction(new EventHandler<ActionEvent>() {
            
            @Override
            public void handle(ActionEvent event) {
                scene = s2;
                primaryStage.setScene(scene);
                primaryStage.show();
            }
        });
        b2.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                scene = s1; 
                primaryStage.setScene(scene);
                primaryStage.show();
            }
        });
        scene = s1;
        
        primaryStage.setTitle("Switch Screens Idea");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    
    public void setUp2ndScene()
    {
        bp = new BorderPane();
        b2 = new Button();
        b2.setText("Go Back");
        bp.setCenter(b2);
        bp.setTop(new Text("This is 2nd screen"));
    }
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }
    
}
